extends Area3D

signal hit_player(damage: int)

@export var speed: float = 8.5
@export var damage: int = 12
var velocity: Vector3 = Vector3.ZERO
var lifetime: float = 3.5

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func launch(direction: Vector3) -> void:
	velocity = direction.normalized() * speed

func _physics_process(delta: float) -> void:
	global_position += velocity * delta
	lifetime -= delta
	if lifetime <= 0.0:
		queue_free()

func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("player"):
		hit_player.emit(damage)
		queue_free()
	elif not body.is_in_group("enemy"):
		queue_free()
